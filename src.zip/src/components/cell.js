import React, { Component } from 'react'

export class cell extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default cell
